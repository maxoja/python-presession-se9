import tkinter as tk
import tkinter.messagebox
import random

class Mainwindow:
    def __init__(self):

        self.all_students = []
        self.temp_all_students = []
        self.filename = "student_name.txt"
        self.get_student_name_from_file()
        self.team_number = 1
        
        window = tk.Tk()
        # code goes here
        self.new_name = tk.StringVar(window)
        #self.group_size = tk.StringVar(window)
        #self.group_size.set("3")
        
        self.add_button = tk.Button(window,text = "add", command = self.add_student)
        self.remove_button = tk.Button(window,text = "remove", command = self.remove_student)
        self.random_button = tk.Button(window,text = "random", command = self.random_group)
        self.name_label = tk.Label(window, text = "student name: ")
        self.group_size_label = tk.Label(window, text = "group size: ")
        self.name_entry = tk.Entry(window, textvariable = self.new_name)
        #self.group_size_entry = tk.Entry(window, textvariable = self.group_size)
        self.group_size_box = tk.Spinbox(window, from_ = 1, to = 10)
        self.name_lb = tk.Listbox(window)

        self.name_label.pack()
        self.name_entry.pack()
        self.add_button.pack()
        self.remove_button.pack()
        self.group_size_label.pack()
        self.group_size_box.pack()
        #self.group_size_entry.pack()
        self.random_button.pack()
        self.name_lb.pack()

        self.update_name_listbox()

        self.reset_team_file()
        
        window.mainloop()

    def reset_team_file(self):
        file = open("team.txt", "w")
        file.close()

    def get_student_name_from_file(self):
        try:
            outfile = open(self.filename,"r")
        except:
            print("Error: Can't open file name '"+self.filename+"'.")
            outfile.close()
            return

        for line in outfile:
            if line.strip() != "":
                self.all_students.append(line.strip())

        self.temp_all_students = self.all_students
            
    def add_student(self):
        try:
            infile = open(self.filename,"w")
        except:
            print("Error: Can't open file name '"+self.filename+"'.")
            infile.close()
            return
        
        if self.new_name.get() != "":
            if not (self.new_name.get() in self.all_students):
                self.all_students.append(self.new_name.get())
                self.print_all_students()
                self.temp_all_students.append(self.new_name.get())
        for name in self.all_students:
            infile.write(name+"\n")

        infile.close()
        self.update_name_listbox()
        
    def remove_student(self):
        try:
            infile = open(self.filename,"w")
        except:
            print("Error: Can't open file name '"+self.filename+"'.")
            infile.close()
            return
        
        if self.new_name.get() in self.all_students and self.new_name.get() != "":
            self.all_students.remove(self.new_name.get())
            self.print_all_students()
            self.temp_all_students.append(self.new_name.get())
        for name in self.all_students:
            infile.write(name+"\n")

        infile.close()
        
        self.update_name_listbox()
        
    def update_name_listbox(self):
        self.name_lb.delete(0, self.name_lb.size())
        i = 0
        for name in self.all_students:
            self.name_lb.insert(i,str(i+1)+". "+name)
            i += 1

    def random_group(self):
        names = ""
        if len(self.temp_all_students) >= int(self.group_size_box.get()):
            for i in range(int(self.group_size_box.get())):
                names += self.temp_all_students.pop(random.randrange(len(self.temp_all_students))) + "\n"
        else:
            for name in self.temp_all_students:
                names += name + "\n"
            self.temp_all_students.clear()
        if names:
            tkinter.messagebox.showwarning("Team " + str(self.team_number), names)
            team_txt = open("team.txt", "a")
            team_txt.write("Team " + str(self.team_number) + ": " + str(names.strip().split("\n")) + "\n")
            self.team_number += 1
            team_txt.close()
        else:
            tkinter.messagebox.showerror("Empty Team", " ")
                        
    def print_all_students(self):
        for name in self.all_students:
            print(name)
            

def main():
    mainwindow = Mainwindow()

main()
