#import some functions used in this program
from math import sin, pi
from turtle import *

#getting input into variables
radius = float(input('enter radius of the circle : '))
angle_in_degree = float(input('enter angle (in degree) : '))

#convert degree to radian
angle_in_radian = angle_in_degree * pi / 180

#calculate chord length
chord_length = 2 * radius * sin(angle_in_radian/2)

#print result
print('the chord length of the circle is :', chord_length)

#visualize using turtle library
speed(1)
circle(radius)
left(90)
forward(radius)
right(180-angle_in_degree)
forward(radius)
right(180 - (180 - angle_in_degree)/2)
forward(chord_length)

input('press enter to exit this program')

exit()




#import some functions used in this program
from math import sin, pi
from turtle import *

#getting input into variables
radius = float(input('enter radius of the circle : '))
angle_in_degree = float(input('enter angle (in degree) : '))

#convert degree to radian
angle_in_radian = angle_in_degree * pi / 180

#calculate chord length
chord_length = 2 * radius * sin(angle_in_radian/2)

#print result
print('the chord length of the circle is :', chord_length)

#visualize using turtle library
speed(1)
circle(radius)
left(90)
forward(radius)
right(180-angle_in_degree)
forward(radius)
right(180 - (180 - angle_in_degree)/2)
forward(chord_length)

input('press enter to exit this program')

exit()
